-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2014 at 09:23 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `upwords`
--
CREATE DATABASE IF NOT EXISTS `upwords` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `upwords`;

-- --------------------------------------------------------

--
-- Table structure for table `jc_commentmeta`
--

CREATE TABLE IF NOT EXISTS `jc_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jc_commentmeta`
--

INSERT INTO `jc_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_wp_trash_meta_status', '1'),
(2, 1, '_wp_trash_meta_time', '1407949569');

-- --------------------------------------------------------

--
-- Table structure for table `jc_comments`
--

CREATE TABLE IF NOT EXISTS `jc_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jc_comments`
--

INSERT INTO `jc_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-08-09 13:43:51', '2014-08-09 13:43:51', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'trash', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jc_links`
--

CREATE TABLE IF NOT EXISTS `jc_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jc_options`
--

CREATE TABLE IF NOT EXISTS `jc_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=474 ;

--
-- Dumping data for table `jc_options`
--

INSERT INTO `jc_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/upwork', 'yes'),
(2, 'blogname', 'UPWORDS', 'yes'),
(3, 'blogdescription', 'Just another WordPress site', 'yes'),
(4, 'users_can_register', '1', 'yes'),
(5, 'admin_email', 'trungnguyenthanh70@gmail.com', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '1', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '', 'yes'),
(10, 'comments_notify', '', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'closed', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '', 'yes'),
(21, 'posts_per_page', '10', 'yes'),
(22, 'date_format', 'F j, Y', 'yes'),
(23, 'time_format', 'g:i a', 'yes'),
(24, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(25, 'comment_moderation', '', 'yes'),
(26, 'moderation_notify', '', 'yes'),
(27, 'permalink_structure', '/%postname%/', 'yes'),
(28, 'gzipcompression', '0', 'yes'),
(29, 'hack_file', '0', 'yes'),
(30, 'blog_charset', 'UTF-8', 'yes'),
(31, 'moderation_keys', '', 'no'),
(32, 'active_plugins', 'a:2:{i:0;s:36:"contact-form-7/wp-contact-form-7.php";i:1;s:51:"static-html-output-plugin/wp-static-html-output.php";}', 'yes'),
(33, 'home', 'http://localhost/upwork', 'yes'),
(34, 'category_base', '/category', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', 'a:5:{i:0;s:67:"/opt/lampp/htdocs/upwork/wp-content/themes/twentythirteen/style.css";i:1;s:69:"/opt/lampp/htdocs/upwork/wp-content/themes/twentythirteen/archive.php";i:2;s:65:"/opt/lampp/htdocs/upwork/wp-content/themes/twentythirteen/tag.php";i:3;s:66:"/opt/lampp/htdocs/upwork/wp-content/themes/twentythirteen/page.php";i:4;s:67:"/opt/lampp/htdocs/upwork/wp-content/themes/twentythirteen/index.php";}', 'no'),
(41, 'template', 'twentythirteen', 'yes'),
(42, 'stylesheet', 'twentythirteen', 'yes'),
(43, 'comment_whitelist', '', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '27916', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '0', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '/tag', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:10:{i:1;a:0:{}i:3;a:3:{s:5:"title";s:9:"product 1";s:4:"text";s:24:"The content of product 1";s:6:"filter";b:0;}i:4;a:3:{s:5:"title";s:9:"Product 2";s:4:"text";s:24:"The content of Product 2";s:6:"filter";b:0;}i:5;a:3:{s:5:"title";s:9:"product 3";s:4:"text";s:24:"the content of Product 3";s:6:"filter";b:0;}i:6;a:3:{s:5:"title";s:9:"product 4";s:4:"text";s:9:"product 4";s:6:"filter";b:0;}i:7;a:3:{s:5:"title";s:9:"product 5";s:4:"text";s:9:"product 5";s:6:"filter";b:0;}i:8;a:3:{s:5:"title";s:9:"product 6";s:4:"text";s:9:"product 6";s:6:"filter";b:0;}i:9;a:3:{s:5:"title";s:9:"product 7";s:4:"text";s:9:"product 7";s:6:"filter";b:0;}i:10;a:3:{s:5:"title";s:9:"product 8";s:4:"text";s:9:"product 8";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '5', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '27916', 'yes'),
(89, 'jc_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:8:{i:0;s:6:"text-3";i:1;s:6:"text-4";i:2;s:6:"text-5";i:3;s:6:"text-6";i:4;s:6:"text-7";i:5;s:6:"text-8";i:6;s:6:"text-9";i:7;s:7:"text-10";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1408455835;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408455847;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1408475160;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408478929;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.2-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.2-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.2";s:7:"version";s:5:"3.9.2";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1408432033;s:15:"version_checked";s:5:"3.9.2";s:12:"translations";a:0:{}}', 'yes'),
(112, 'can_compress_scripts', '1', 'yes'),
(126, '_site_transient_timeout_wporg_theme_feature_list', '1407602653', 'yes'),
(127, '_site_transient_wporg_theme_feature_list', 'a:4:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:6:"Layout";a:9:{i:0;s:12:"fixed-layout";i:1;s:12:"fluid-layout";i:2;s:17:"responsive-layout";i:3;s:10:"one-column";i:4;s:11:"two-columns";i:5;s:13:"three-columns";i:6;s:12:"four-columns";i:7;s:12:"left-sidebar";i:8;s:13:"right-sidebar";}s:8:"Features";a:20:{i:0;s:19:"accessibility-ready";i:1;s:8:"blavatar";i:2;s:10:"buddypress";i:3;s:17:"custom-background";i:4;s:13:"custom-colors";i:5;s:13:"custom-header";i:6;s:11:"custom-menu";i:7;s:12:"editor-style";i:8;s:21:"featured-image-header";i:9;s:15:"featured-images";i:10;s:15:"flexible-header";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes'),
(130, 'current_theme', 'Twenty Thirteen', 'yes'),
(131, 'theme_mods_roots-roots-dd7635c', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1407692955;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";a:0:{}}}}', 'yes'),
(132, 'theme_switched', '', 'yes'),
(141, '_transient_random_seed', 'b09eb9335582e9e0ec4c1cf083e1c3e0', 'yes'),
(143, 'theme_mods_roots', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:0;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1407694955;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";a:0:{}}}}', 'yes'),
(144, 'theme_switched_via_customizer', '', 'yes'),
(145, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(147, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(148, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(175, 'theme_mods_organic_photographer', 'a:1:{i:0;b:0;}', 'yes'),
(176, 'woocommerce_thumbnail_image_width', '192', 'yes'),
(177, 'woocommerce_thumbnail_image_height', '192', 'yes'),
(178, 'woocommerce_single_image_width', '600', 'yes'),
(179, 'woocommerce_single_image_height', '600', 'yes'),
(180, 'woocommerce_catalog_image_width', '140', 'yes'),
(181, 'woocommerce_catalog_image_height', '140', 'yes'),
(202, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";s:4:"tuvd";s:15:"connection_type";s:3:"ftp";}', 'yes'),
(204, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1408432034;s:7:"checked";a:1:{s:14:"twentythirteen";s:3:"1.2";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'),
(207, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1407780376;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}}}}', 'yes'),
(208, 'theme_mods_twentythirteen', 'a:4:{i:0;b:0;s:16:"header_textcolor";s:6:"220e10";s:12:"header_image";s:13:"remove-header";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:0;}}', 'yes'),
(215, 'recently_activated', 'a:0:{}', 'yes'),
(241, 'rewrite_rules', 'a:68:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(427, 'category_children', 'a:0:{}', 'yes'),
(432, 'wp-static-html-output-options', 'a:10:{s:7:"version";s:5:"1.1.0";s:7:"baseUrl";s:23:"http://localhost/upwork";s:14:"additionalUrls";s:0:"";s:11:"generateZip";s:0:"";s:17:"retainStaticFiles";s:0:"";s:10:"sendViaFTP";s:0:"";s:9:"ftpServer";s:0:"";s:11:"ftpUsername";s:0:"";s:11:"ftpPassword";s:0:"";s:13:"ftpRemotePath";s:0:"";}', 'yes'),
(434, '_site_transient_timeout_browser_1564c83f163c4dbfafb7384ebe95b8f4', '1408903166', 'yes'),
(435, '_site_transient_browser_1564c83f163c4dbfafb7384ebe95b8f4', 'a:9:{s:8:"platform";s:5:"Linux";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"36.0.1985.125";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'),
(455, '_site_transient_timeout_theme_roots', '1408432902', 'yes'),
(456, '_site_transient_theme_roots', 'a:1:{s:14:"twentythirteen";s:7:"/themes";}', 'yes'),
(458, '_transient_timeout_plugin_slugs', '1408518147', 'no'),
(459, '_transient_plugin_slugs', 'a:4:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:9:"hello.php";i:3;s:51:"static-html-output-plugin/wp-static-html-output.php";}', 'no'),
(460, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1408474383', 'no'),
(461, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><p><strong>RSS Error</strong>: A feed could not be found at http://wordpress.org/news/feed/. A feed with an invalid mime type may fall victim to this error, or SimplePie was unable to auto-discover it.. Use force_feed() if you are certain this URL is a real feed.</p></div><div class="rss-widget"><p><strong>RSS Error</strong>: A feed could not be found at http://planet.wordpress.org/feed/. A feed with an invalid mime type may fall victim to this error, or SimplePie was unable to auto-discover it.. Use force_feed() if you are certain this URL is a real feed.</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(462, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1408441988', 'yes'),
(463, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4587";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2848";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2785";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2284";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2189";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1792";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1587";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1563";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1529";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1519";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1448";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1411";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1350";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1209";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1153";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1121";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1044";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1001";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"995";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"823";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"811";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"798";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"793";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"789";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"730";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"693";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"691";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"661";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"638";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"618";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"609";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"607";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"601";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"593";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"587";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"546";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"544";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"543";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"536";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"534";}}', 'yes'),
(465, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.9.1";}', 'yes'),
(470, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1408432034;s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.2.zip";}}s:12:"translations";a:0:{}}', 'yes'),
(473, '_transient_is_multi_author', '1', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `jc_postmeta`
--

CREATE TABLE IF NOT EXISTS `jc_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=218 ;

--
-- Dumping data for table `jc_postmeta`
--

INSERT INTO `jc_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'main-template.php'),
(4, 7, '_menu_item_type', 'post_type'),
(5, 7, '_menu_item_menu_item_parent', '0'),
(6, 7, '_menu_item_object_id', '5'),
(7, 7, '_menu_item_object', 'page'),
(8, 7, '_menu_item_target', ''),
(9, 7, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(10, 7, '_menu_item_xfn', ''),
(11, 7, '_menu_item_url', ''),
(12, 8, '_menu_item_type', 'post_type'),
(13, 8, '_menu_item_menu_item_parent', '0'),
(14, 8, '_menu_item_object_id', '2'),
(15, 8, '_menu_item_object', 'page'),
(16, 8, '_menu_item_target', ''),
(17, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(18, 8, '_menu_item_xfn', ''),
(19, 8, '_menu_item_url', ''),
(22, 1, '_edit_lock', '1408286578:2'),
(23, 1, '_edit_last', '2'),
(26, 5, '_edit_lock', '1408298158:2'),
(27, 5, '_edit_last', '2'),
(28, 5, '_wp_page_template', 'main-template.php'),
(29, 2, '_edit_lock', '1407874163:2'),
(30, 2, '_edit_last', '2'),
(31, 14, '_edit_lock', '1408045957:2'),
(32, 14, '_edit_last', '2'),
(33, 14, '_wp_page_template', 'main-template.php'),
(34, 16, '_edit_lock', '1408042697:2'),
(35, 16, '_edit_last', '2'),
(36, 16, '_wp_page_template', 'main-template.php'),
(37, 18, '_edit_lock', '1407874116:2'),
(38, 18, '_edit_last', '2'),
(39, 18, '_wp_page_template', 'main-template.php'),
(42, 20, '_edit_lock', '1407874200:2'),
(43, 20, '_edit_last', '2'),
(44, 20, '_wp_page_template', 'main-template.php'),
(45, 22, '_edit_lock', '1408432738:2'),
(46, 22, '_edit_last', '2'),
(47, 22, '_wp_page_template', 'main-template.php'),
(48, 25, '_wp_attached_file', '2014/08/love2_large.jpg'),
(49, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:23:"2014/08/love2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"love2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"love2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(51, 26, '_wp_attached_file', '2014/08/celebrate2_large.jpg'),
(52, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:28:"2014/08/celebrate2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"celebrate2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"celebrate2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(54, 27, '_wp_attached_file', '2014/08/Mom_Girl_Celebrate.jpg'),
(55, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:755;s:6:"height";i:567;s:4:"file";s:30:"2014/08/Mom_Girl_Celebrate.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Mom_Girl_Celebrate-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"Mom_Girl_Celebrate-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:30:"Mom_Girl_Celebrate-604x270.jpg";s:5:"width";i:604;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(56, 28, '_wp_attached_file', '2014/08/Mom_Girl_Love.jpg'),
(57, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:755;s:6:"height";i:567;s:4:"file";s:25:"2014/08/Mom_Girl_Love.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Mom_Girl_Love-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Mom_Girl_Love-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Mom_Girl_Love-604x270.jpg";s:5:"width";i:604;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(59, 1, 'img_url', 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg'),
(61, 1, '_wp_old_slug', 'hello-world'),
(62, 30, '_edit_lock', '1408041829:2'),
(63, 30, '_edit_last', '2'),
(65, 30, '_thumbnail_id', '25'),
(66, 30, 'img_url', 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Love.jpg'),
(68, 33, '_edit_lock', '1408286583:2'),
(70, 33, '_edit_last', '2'),
(71, 35, '_wp_attached_file', '2014/08/overcome2_large.jpg'),
(72, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:27:"2014/08/overcome2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"overcome2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"overcome2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(74, 36, '_wp_attached_file', '2014/08/assort_large.jpg'),
(75, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:24:"2014/08/assort_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"assort_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"assort_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(76, 37, '_wp_attached_file', '2014/08/strength2_large.jpg'),
(77, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:27:"2014/08/strength2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"strength2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"strength2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(78, 38, '_wp_attached_file', '2014/08/life2_large.jpg'),
(79, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:23:"2014/08/life2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"life2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"life2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(80, 39, '_wp_attached_file', '2014/08/joy2_large.jpg'),
(81, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:22:"2014/08/joy2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"joy2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"joy2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(82, 40, '_wp_attached_file', '2014/08/compassion3_large.jpg'),
(83, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:29:"2014/08/compassion3_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"compassion3_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"compassion3_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(88, 33, 'img_url', 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Overcome.jpg'),
(93, 43, '_wp_attached_file', '2014/08/the_footer_card.png'),
(94, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:299;s:6:"height";i:184;s:4:"file";s:27:"2014/08/the_footer_card.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"the_footer_card-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(95, 44, '_wp_attached_file', '2014/08/the_footer_gril.png'),
(96, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:299;s:6:"height";i:184;s:4:"file";s:27:"2014/08/the_footer_gril.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"the_footer_gril-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(97, 1, '_thumbnail_id', '26'),
(98, 52, '_wp_attached_file', '2014/08/Mom_Girl_Overcome.jpg'),
(99, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:708;s:6:"height";i:532;s:4:"file";s:29:"2014/08/Mom_Girl_Overcome.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Mom_Girl_Overcome-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"Mom_Girl_Overcome-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:29:"Mom_Girl_Overcome-604x270.jpg";s:5:"width";i:604;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(100, 33, '_thumbnail_id', '35'),
(101, 53, '_edit_lock', '1408288073:2'),
(102, 53, '_edit_last', '2'),
(103, 54, '_wp_attached_file', '2014/08/Mom_Girl_Thank.jpg'),
(104, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:755;s:6:"height";i:567;s:4:"file";s:26:"2014/08/Mom_Girl_Thank.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Mom_Girl_Thank-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Mom_Girl_Thank-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Mom_Girl_Thank-604x270.jpg";s:5:"width";i:604;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(105, 55, '_wp_attached_file', '2014/08/thanks2_large.jpg'),
(106, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:258;s:4:"file";s:25:"2014/08/thanks2_large.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"thanks2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"thanks2_large-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(107, 53, '_thumbnail_id', '55'),
(108, 53, 'img_url', 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Thank.jpg'),
(111, 57, '_edit_lock', '1408241768:2'),
(112, 57, '_edit_last', '2'),
(117, 65, '_edit_lock', '1408273666:2'),
(118, 65, '_edit_last', '2'),
(119, 66, '_wp_attached_file', '2014/08/Veronica_2_large.jpg'),
(120, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:360;s:4:"file";s:28:"2014/08/Veronica_2_large.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Veronica_2_large-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Veronica_2_large-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Veronica_2_large-480x270.jpg";s:5:"width";i:480;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(121, 65, '_thumbnail_id', '66'),
(124, 70, '_edit_lock', '1408300956:2'),
(125, 70, '_edit_last', '2'),
(126, 71, '_wp_attached_file', '2014/08/20140402_110908_resized_medium.jpg'),
(127, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:180;s:6:"height";i:240;s:4:"file";s:42:"2014/08/20140402_110908_resized_medium.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"20140402_110908_resized_medium-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(128, 70, '_thumbnail_id', '71'),
(132, 74, '_edit_lock', '1408289078:2'),
(133, 74, '_edit_last', '2'),
(137, 77, '_edit_lock', '1408289546:2'),
(138, 77, '_edit_last', '2'),
(139, 78, '_wp_attached_file', '2014/08/ANGEL_Wife.jpg'),
(140, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:212;s:4:"file";s:22:"2014/08/ANGEL_Wife.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"ANGEL_Wife-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(141, 77, '_thumbnail_id', '78'),
(144, 80, '_edit_lock', '1408289648:2'),
(145, 80, '_edit_last', '2'),
(146, 81, '_wp_attached_file', '2014/08/Carey.jpg'),
(147, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:211;s:6:"height";i:212;s:4:"file";s:17:"2014/08/Carey.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Carey-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(148, 80, '_thumbnail_id', '81'),
(150, 83, '_edit_lock', '1408289730:2'),
(151, 83, '_edit_last', '2'),
(152, 84, '_wp_attached_file', '2014/08/Michael.jpg'),
(153, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:212;s:4:"file";s:19:"2014/08/Michael.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"Michael-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(154, 83, '_thumbnail_id', '84'),
(156, 86, '_edit_lock', '1408289801:2'),
(157, 86, '_edit_last', '2'),
(158, 87, '_wp_attached_file', '2014/08/Life_Stories4.jpg'),
(159, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:210;s:4:"file";s:25:"2014/08/Life_Stories4.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Life_Stories4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(160, 86, '_thumbnail_id', '87'),
(162, 89, '_edit_lock', '1408293637:2'),
(163, 89, '_edit_last', '2'),
(166, 91, '_edit_lock', '1408290041:2'),
(167, 91, '_edit_last', '2'),
(168, 92, '_wp_attached_file', '2014/08/Life_Stories5.jpg'),
(169, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:210;s:4:"file";s:25:"2014/08/Life_Stories5.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Life_Stories5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(170, 91, '_thumbnail_id', '92'),
(172, 94, '_edit_lock', '1408290133:2'),
(173, 94, '_edit_last', '2'),
(174, 95, '_wp_attached_file', '2014/08/Life_Stories6.jpg'),
(175, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:211;s:4:"file";s:25:"2014/08/Life_Stories6.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Life_Stories6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(176, 94, '_thumbnail_id', '95'),
(178, 97, '_edit_lock', '1408290166:2'),
(179, 97, '_edit_last', '2'),
(180, 98, '_wp_attached_file', '2014/08/Life_Stories7.jpg'),
(181, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:211;s:6:"height";i:211;s:4:"file";s:25:"2014/08/Life_Stories7.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Life_Stories7-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(182, 97, '_thumbnail_id', '98'),
(184, 100, '_edit_lock', '1408290204:2'),
(185, 100, '_edit_last', '2'),
(186, 101, '_wp_attached_file', '2014/08/Life_Stories8.jpg'),
(187, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:212;s:6:"height";i:211;s:4:"file";s:25:"2014/08/Life_Stories8.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Life_Stories8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(188, 100, '_thumbnail_id', '101'),
(191, 106, '_edit_lock', '1408294464:2'),
(192, 106, '_edit_last', '2'),
(193, 107, '_wp_attached_file', '2014/08/Web_Causes_PageP11.png'),
(194, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:211;s:6:"height";i:196;s:4:"file";s:30:"2014/08/Web_Causes_PageP11.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Web_Causes_PageP11-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(195, 106, '_thumbnail_id', '107'),
(197, 109, '_edit_lock', '1408294582:2'),
(198, 109, '_edit_last', '2'),
(199, 110, '_wp_attached_file', '2014/08/Web_Causes_PageP21.png'),
(200, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:211;s:6:"height";i:181;s:4:"file";s:30:"2014/08/Web_Causes_PageP21.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Web_Causes_PageP21-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(201, 109, '_thumbnail_id', '110'),
(203, 112, '_edit_lock', '1408296276:2'),
(204, 112, '_edit_last', '2'),
(205, 113, '_wp_attached_file', '2014/08/Web_Causes_PageP31.png'),
(206, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:211;s:6:"height";i:176;s:4:"file";s:30:"2014/08/Web_Causes_PageP31.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Web_Causes_PageP31-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(207, 112, '_thumbnail_id', '113'),
(209, 115, '_edit_lock', '1408297209:2'),
(210, 115, '_edit_last', '2'),
(211, 115, '_wp_page_template', 'main-template.php'),
(212, 119, '_form', '<div class="form-left">\n<div class="row">\n<label>First Name <span>*</span></label>\n    [text* first-name] </div>\n<div class="row">\n<label>Last Name <span>*</span></label>\n    [text* last-name] </div>\n<div class="row">\n<label>Email<span>*</span></label>\n     [email* your-email]  </div>\n<div class="row">\n<label>Home Phone </label>\n    [text hphone-name] </div>\n	<div class="row">\n<label>Cell phone</label>\n    [text cellphone-name] </div>\n</div>\n<div class="form-right">\n<div class="row message">\n<label>Your Message</label>\n    [textarea your-message] </div>\n\n<div class="sm">[submit "Send"]</div>	\n</div>'),
(213, 119, '_mail', 'a:8:{s:7:"subject";s:51:"This e-mail was sent from a contact form on UPWORDS";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:198:"From: [your-name] <[your-email]>\nHome phone: [hphone-name]\nCell phone: [cellphone-name]\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on UPWORDS (http://localhost/upwork)";s:9:"recipient";s:28:"trungnguyenthanh70@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(214, 119, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:110:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on UPWORDS (http://localhost/upwork)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(215, 119, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}'),
(216, 119, '_additional_settings', ''),
(217, 119, '_locale', 'en_US');

-- --------------------------------------------------------

--
-- Table structure for table `jc_posts`
--

CREATE TABLE IF NOT EXISTS `jc_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=124 ;

--
-- Dumping data for table `jc_posts`
--

INSERT INTO `jc_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2014-08-12 18:43:51', '2014-08-12 18:43:51', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg" alt="" /></div>\r\n\r\n<div class="text-content">\r\n<em style="color: #333333;">This card can be used for letting someone know how special their life is, celebrating a new job, a move, a birthday or any life festivity!</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326" style="color: #002060;"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Celebrate', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'publish', 'closed', 'open', '', 'celebrate', '', '', '2014-08-13 19:12:28', '2014-08-13 19:12:28', '', 0, 'http://localhost/UPWORDS/?p=1', 0, 'post', '', 0),
(2, 1, '2014-08-09 13:43:51', '2014-08-09 13:43:51', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/UPWORDS/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Shop Page', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2014-08-12 20:11:29', '2014-08-12 20:11:29', '', 0, 'http://localhost/UPWORDS/?page_id=2', 0, 'page', '', 0),
(5, 1, '2014-08-09 13:45:31', '2014-08-09 13:45:31', 'Home', 'Home', '', 'publish', 'closed', 'open', '', 'home', '', '', '2014-08-17 17:58:20', '2014-08-17 17:58:20', '', 0, 'http://localhost/UPWORDS/?page_id=5', -1, 'page', '', 0),
(6, 1, '2014-08-09 13:45:32', '2014-08-09 13:45:32', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arcu adipiscing imperdiet vitae sit amet neque. Integer eu lectus et nunc dictum sagittis. Curabitur commodo vulputate fringilla. Sed eleifend, arcu convallis adipiscing congue, dui turpis commodo magna, et vehicula sapien turpis sit amet nisi.', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2014-08-09 13:45:32', '2014-08-09 13:45:32', '', 5, 'http://localhost/UPWORDS/?p=6', 0, 'revision', '', 0),
(7, 1, '2014-08-09 13:45:32', '2014-08-09 13:45:32', ' ', '', '', 'publish', 'open', 'open', '', '7', '', '', '2014-08-09 13:45:32', '2014-08-09 13:45:32', '', 0, 'http://localhost/UPWORDS/7/', 0, 'nav_menu_item', '', 0),
(8, 1, '2014-08-09 13:45:32', '2014-08-09 13:45:32', ' ', '', '', 'publish', 'open', 'open', '', '8', '', '', '2014-08-09 13:45:32', '2014-08-09 13:45:32', '', 0, 'http://localhost/UPWORDS/8/', 2, 'nav_menu_item', '', 0),
(10, 2, '2014-08-11 18:14:58', '2014-08-11 18:14:58', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-08-11 18:14:58', '2014-08-11 18:14:58', '', 1, 'http://localhost/upwork/1-revision-v1/', 0, 'revision', '', 0),
(11, 2, '2014-08-12 19:59:25', '2014-08-12 19:59:25', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/UPWORDS/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-08-12 19:59:25', '2014-08-12 19:59:25', '', 2, 'http://localhost/upwork/2-revision-v1/', 0, 'revision', '', 0),
(12, 2, '2014-08-12 19:59:45', '2014-08-12 19:59:45', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/UPWORDS/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Shop Page', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-08-12 19:59:45', '2014-08-12 19:59:45', '', 2, 'http://localhost/upwork/2-revision-v1/', 0, 'revision', '', 0),
(13, 2, '2014-08-12 20:08:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-12 20:08:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?page_id=13', 0, 'page', '', 0),
(14, 1, '2014-08-12 20:10:05', '2014-08-12 20:10:05', '<div class="the-image"><img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png" width="300px"/></div>\r\n<div class="content">\r\n <span class="title">LIFE STORIES</span><br />\r\n <span class="excerpt">Celebrate life during the holidays with cheerful messages.</span>\r\n</div>\r\n', 'Life Stories', '', 'publish', 'closed', 'open', '', 'life', '', '', '2014-08-14 19:01:16', '2014-08-14 19:01:16', '', 0, 'http://localhost/upwork/?page_id=14', 1, 'page', '', 0),
(15, 2, '2014-08-12 20:10:05', '2014-08-12 20:10:05', 'Life Stories', 'Life Stories', '', 'inherit', 'closed', 'open', '', '14-revision-v1', '', '', '2014-08-12 20:10:05', '2014-08-12 20:10:05', '', 14, 'http://localhost/upwork/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2014-08-12 20:10:32', '2014-08-12 20:10:32', '<div class="the-image"><img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_gril.png" width="300px"/></div>\r\n<div class="content">\r\n <span class="title">ABOUT</span><br />\r\n <span class="excerpt">UPwords was founded 20 years ago with a compassionate mission.</span>\r\n</div>', 'About', '', 'publish', 'closed', 'open', '', 'about', '', '', '2014-08-14 19:00:39', '2014-08-14 19:00:39', '', 0, 'http://localhost/upwork/?page_id=16', 2, 'page', '', 0),
(17, 2, '2014-08-12 20:10:32', '2014-08-12 20:10:32', 'about', 'About', '', 'inherit', 'closed', 'open', '', '16-revision-v1', '', '', '2014-08-12 20:10:32', '2014-08-12 20:10:32', '', 16, 'http://localhost/upwork/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2014-08-12 20:10:58', '2014-08-12 20:10:58', 'causes', 'Causes', '', 'publish', 'closed', 'open', '', 'causes', '', '', '2014-08-12 20:11:29', '2014-08-12 20:11:29', '', 0, 'http://localhost/upwork/?page_id=18', 3, 'page', '', 0),
(19, 2, '2014-08-12 20:10:58', '2014-08-12 20:10:58', 'causes', 'Causes', '', 'inherit', 'closed', 'open', '', '18-revision-v1', '', '', '2014-08-12 20:10:58', '2014-08-12 20:10:58', '', 18, 'http://localhost/upwork/18-revision-v1/', 0, 'revision', '', 0),
(20, 2, '2014-08-12 20:12:19', '2014-08-12 20:12:19', 'blog', 'Blog', '', 'publish', 'closed', 'open', '', 'blog', '', '', '2014-08-12 20:12:23', '2014-08-12 20:12:23', '', 0, 'http://localhost/upwork/?page_id=20', 4, 'page', '', 0),
(21, 2, '2014-08-12 20:12:19', '2014-08-12 20:12:19', 'blog', 'Blog', '', 'inherit', 'closed', 'open', '', '20-revision-v1', '', '', '2014-08-12 20:12:19', '2014-08-12 20:12:19', '', 20, 'http://localhost/upwork/20-revision-v1/', 0, 'revision', '', 0),
(22, 2, '2014-08-12 20:12:41', '2014-08-12 20:12:41', '<strong>UpWords</strong>\r\n\r\nPO Box 958152\r\n\r\nDuluth , GA 30095\r\n\r\ninfo@upwords.me\r\n\r\n[contact-form-7 id="119" title="Contact form"]', 'Contact', '', 'publish', 'closed', 'open', '', 'contact', '', '', '2014-08-19 07:13:07', '2014-08-19 07:13:07', '', 0, 'http://localhost/upwork/?page_id=22', 5, 'page', '', 0),
(23, 2, '2014-08-12 20:12:41', '2014-08-12 20:12:41', 'contact', 'Contact', '', 'inherit', 'closed', 'open', '', '22-revision-v1', '', '', '2014-08-12 20:12:41', '2014-08-12 20:12:41', '', 22, 'http://localhost/upwork/22-revision-v1/', 0, 'revision', '', 0),
(24, 2, '2014-08-13 17:40:05', '2014-08-13 17:40:05', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg" alt="" /></div>\n<div class="text-content">\n<em style="color: #333333;">This card can be used for letting someone know how special their life is, celebrating a new job, a move, a birthday or any life festivity!</em>\n<ul style="color: #333333;">\n	<li>3.5 x 2 folded.</li>\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\n	<li>Sized for hand delivery.</li>\n	<li><span id="yui_3_13_0_1_1397524186692_6326" style="color: #002060;"></span>Envelopes included.</li>\n</ul>\n</div>', 'Celebrate', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '1-autosave-v1', '', '', '2014-08-13 17:40:05', '2014-08-13 17:40:05', '', 1, 'http://localhost/upwork/1-autosave-v1/', 0, 'revision', '', 0),
(25, 2, '2014-08-13 17:11:57', '2014-08-13 17:11:57', '', 'love2_large', '', 'inherit', 'closed', 'open', '', 'love2_large', '', '', '2014-08-13 17:11:57', '2014-08-13 17:11:57', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/love2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 2, '2014-08-13 17:21:52', '2014-08-13 17:21:52', '', 'celebrate2_large', '', 'inherit', 'closed', 'open', '', 'celebrate2_large', '', '', '2014-08-13 17:21:52', '2014-08-13 17:21:52', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/celebrate2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 2, '2014-08-13 17:23:40', '2014-08-13 17:23:40', '', 'Mom_Girl_Celebrate', '', 'inherit', 'closed', 'open', '', 'mom_girl_celebrate', '', '', '2014-08-13 17:23:40', '2014-08-13 17:23:40', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 2, '2014-08-13 17:23:49', '2014-08-13 17:23:49', '', 'Mom_Girl_Love', '', 'inherit', 'closed', 'open', '', 'mom_girl_love', '', '', '2014-08-13 17:23:49', '2014-08-13 17:23:49', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Love.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 2, '2014-08-13 17:36:41', '2014-08-13 17:36:41', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg" alt="" /></div>\r\n<em style="color: #333333;">This card can be used for letting someone know how special their life is, celebrating a new job, a move, a birthday or any life festivity!</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326" style="color: #002060;"></span>Envelopes included.</li>\r\n</ul>', 'Celebrate', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-08-13 17:36:41', '2014-08-13 17:36:41', '', 1, 'http://localhost/upwork/1-revision-v1/', 0, 'revision', '', 0),
(30, 2, '2014-08-12 17:42:17', '2014-08-12 17:42:17', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Love.jpg" alt="" /></div>\r\n<div class="text-content">\r\n<p style="color: #333333;"><em>Love can be expressed each day through this simple yet powerful card.</em></p>\r\n\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Love', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'publish', 'closed', 'open', '', 'love', '', '', '2014-08-13 19:12:11', '2014-08-13 19:12:11', '', 0, 'http://localhost/upwork/?p=30', 0, 'post', '', 0),
(31, 2, '2014-08-13 17:40:58', '2014-08-13 17:40:58', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Celebrate.jpg" alt="" /></div>\r\n\r\n<div class="text-content">\r\n<em style="color: #333333;">This card can be used for letting someone know how special their life is, celebrating a new job, a move, a birthday or any life festivity!</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326" style="color: #002060;"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Celebrate', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-08-13 17:40:58', '2014-08-13 17:40:58', '', 1, 'http://localhost/upwork/1-revision-v1/', 0, 'revision', '', 0),
(32, 2, '2014-08-13 17:42:17', '2014-08-13 17:42:17', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Love.jpg" alt="" /></div>\r\n\r\n<div class="text-content">\r\n<p style="color: #333333;"><em>Love can be expressed each day through this simple yet powerful card.</em></p>\r\n\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Love', '', 'inherit', 'closed', 'open', '', '30-revision-v1', '', '', '2014-08-13 17:42:17', '2014-08-13 17:42:17', '', 30, 'http://localhost/upwork/30-revision-v1/', 0, 'revision', '', 0),
(33, 2, '2014-08-13 18:53:25', '2014-08-13 18:53:25', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Overcome.jpg" alt="" /></div>\r\n<div class="text-content"><em style="color: #333333;">Life has valley experiences for all of us and this card is perfect to let someone know that they’re going to come through this time.</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n	<li></li>\r\n</ul>\r\n</div>', 'Overcome', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'publish', 'closed', 'open', '', 'overcome', '', '', '2014-08-13 19:12:41', '2014-08-13 19:12:41', '', 0, 'http://localhost/upwork/?p=33', 0, 'post', '', 0),
(34, 2, '2014-08-13 17:43:26', '2014-08-13 17:43:26', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Love.jpg" alt="" /></div>\r\n<div class="text-content">\r\n<p style="color: #333333;"><em>Love can be expressed each day through this simple yet powerful card.</em></p>\r\n\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Love', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '30-revision-v1', '', '', '2014-08-13 17:43:26', '2014-08-13 17:43:26', '', 30, 'http://localhost/upwork/30-revision-v1/', 0, 'revision', '', 0),
(35, 2, '2014-08-13 17:44:59', '2014-08-13 17:44:59', '', 'overcome2_large', '', 'inherit', 'closed', 'open', '', 'overcome2_large', '', '', '2014-08-13 17:44:59', '2014-08-13 17:44:59', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/overcome2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 2, '2014-08-13 17:46:01', '2014-08-13 17:46:01', '', 'assort_large', '', 'inherit', 'closed', 'open', '', 'assort_large', '', '', '2014-08-13 17:46:01', '2014-08-13 17:46:01', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/assort_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 2, '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 'strength2_large', '', 'inherit', 'closed', 'open', '', 'strength2_large', '', '', '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/strength2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 2, '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 'life2_large', '', 'inherit', 'closed', 'open', '', 'life2_large', '', '', '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/life2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 2, '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 'joy2_large', '', 'inherit', 'closed', 'open', '', 'joy2_large', '', '', '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/joy2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 2, '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 'compassion3_large', '', 'inherit', 'closed', 'open', '', 'compassion3_large', '', '', '2014-08-13 17:46:02', '2014-08-13 17:46:02', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/compassion3_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 2, '2014-08-13 17:53:25', '2014-08-13 17:53:25', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Overcome.jpg" alt="" /></div>\r\n<div class="text-content"><em style="color: #333333;">Life has valley experiences for all of us and this card is perfect to let someone know that they’re going to come through this time.</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n	<li></li>\r\n</ul>\r\n</div>', 'Overcome', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '33-revision-v1', '', '', '2014-08-13 17:53:25', '2014-08-13 17:53:25', '', 33, 'http://localhost/upwork/33-revision-v1/', 0, 'revision', '', 0),
(43, 2, '2014-08-14 18:45:42', '2014-08-14 18:45:42', '', 'the_footer_card', '', 'inherit', 'closed', 'open', '', 'the_footer_card', '', '', '2014-08-14 18:45:42', '2014-08-14 18:45:42', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png', 0, 'attachment', 'image/png', 0),
(44, 2, '2014-08-14 18:45:42', '2014-08-14 18:45:42', '', 'the_footer_gril', '', 'inherit', 'closed', 'open', '', 'the_footer_gril', '', '', '2014-08-14 18:45:42', '2014-08-14 18:45:42', '', 1, 'http://localhost/upwork/wp-content/uploads/2014/08/the_footer_gril.png', 0, 'attachment', 'image/png', 0),
(45, 2, '2014-08-14 18:46:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-14 18:46:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=45', 0, 'post', '', 0),
(46, 2, '2014-08-14 18:52:04', '2014-08-14 18:52:04', '<div class="page-content">\n <img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png" width="300px"/>\n <span class="title">LIFE STORIES</span><br />\n <span class="exr">\n</span></div>', 'Life Stories', '', 'inherit', 'closed', 'open', '', '14-autosave-v1', '', '', '2014-08-14 18:52:04', '2014-08-14 18:52:04', '', 14, 'http://localhost/upwork/14-autosave-v1/', 0, 'revision', '', 0),
(47, 2, '2014-08-14 18:53:04', '2014-08-14 18:53:04', '<div class="page-content">\r\n <img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png" width="300px"/>\r\n <span class="title">LIFE STORIES</span><br />\r\n <span class="excerpt">Celebrate life during the holidays with cheerful messages.</span>\r\n</div>', 'Life Stories', '', 'inherit', 'closed', 'open', '', '14-revision-v1', '', '', '2014-08-14 18:53:04', '2014-08-14 18:53:04', '', 14, 'http://localhost/upwork/14-revision-v1/', 0, 'revision', '', 0),
(48, 2, '2014-08-14 18:54:07', '2014-08-14 18:54:07', '<div class="content">\r\n <img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png" width="300px"/>\r\n <span class="title">LIFE STORIES</span><br />\r\n <span class="excerpt">Celebrate life during the holidays with cheerful messages.</span>\r\n</div>', 'Life Stories', '', 'inherit', 'closed', 'open', '', '14-revision-v1', '', '', '2014-08-14 18:54:07', '2014-08-14 18:54:07', '', 14, 'http://localhost/upwork/14-revision-v1/', 0, 'revision', '', 0),
(49, 2, '2014-08-14 18:55:13', '2014-08-14 18:55:13', '<div class="content">\r\n <img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_gril.png" width="300px"/>\r\n <span class="title">ABOUT</span><br />\r\n <span class="excerpt">UPwords was founded 20 years ago with a compassionate mission.</span>\r\n</div>', 'About', '', 'inherit', 'closed', 'open', '', '16-revision-v1', '', '', '2014-08-14 18:55:13', '2014-08-14 18:55:13', '', 16, 'http://localhost/upwork/16-revision-v1/', 0, 'revision', '', 0),
(50, 2, '2014-08-14 19:00:39', '2014-08-14 19:00:39', '<div class="the-image"><img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_gril.png" width="300px"/></div>\r\n<div class="content">\r\n <span class="title">ABOUT</span><br />\r\n <span class="excerpt">UPwords was founded 20 years ago with a compassionate mission.</span>\r\n</div>', 'About', '', 'inherit', 'closed', 'open', '', '16-revision-v1', '', '', '2014-08-14 19:00:39', '2014-08-14 19:00:39', '', 16, 'http://localhost/upwork/16-revision-v1/', 0, 'revision', '', 0),
(51, 2, '2014-08-14 19:01:16', '2014-08-14 19:01:16', '<div class="the-image"><img src="http://localhost/upwork/wp-content/uploads/2014/08/the_footer_card.png" width="300px"/></div>\r\n<div class="content">\r\n <span class="title">LIFE STORIES</span><br />\r\n <span class="excerpt">Celebrate life during the holidays with cheerful messages.</span>\r\n</div>\r\n', 'Life Stories', '', 'inherit', 'closed', 'open', '', '14-revision-v1', '', '', '2014-08-14 19:01:16', '2014-08-14 19:01:16', '', 14, 'http://localhost/upwork/14-revision-v1/', 0, 'revision', '', 0),
(52, 2, '2014-08-14 19:55:37', '2014-08-14 19:55:37', '', 'Mom_Girl_Overcome', '', 'inherit', 'closed', 'open', '', 'mom_girl_overcome', '', '', '2014-08-14 19:55:37', '2014-08-14 19:55:37', '', 33, 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Overcome.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 2, '2014-08-14 20:13:32', '2014-08-14 20:13:32', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Thank.jpg" alt="" /></div>\r\n<div class="text-content"><em style="color: #333333;">It’s amazing what a simple Thanks can do! You’ve heard of being proactive. You can be the "pro" in active, by caring enough to give a Thanks of gratitude. Perfect for on-the-spot recognition of someone who did something kind for you.</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Thanks', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'publish', 'closed', 'open', '', 'thanks', '', '', '2014-08-17 14:45:36', '2014-08-17 14:45:36', '', 0, 'http://localhost/upwork/?p=53', 0, 'post', '', 0),
(54, 2, '2014-08-14 20:00:53', '2014-08-14 20:00:53', '', 'Mom_Girl_Thank', '', 'inherit', 'closed', 'open', '', 'mom_girl_thank', '', '', '2014-08-14 20:00:53', '2014-08-14 20:00:53', '', 53, 'http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Thank.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 2, '2014-08-14 20:11:14', '2014-08-14 20:11:14', '', 'thanks2_large', '', 'inherit', 'closed', 'open', '', 'thanks2_large', '', '', '2014-08-14 20:11:14', '2014-08-14 20:11:14', '', 53, 'http://localhost/upwork/wp-content/uploads/2014/08/thanks2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 2, '2014-08-14 20:13:32', '2014-08-14 20:13:32', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Thank.jpg" alt="" /></div>\r\n<div class="text-content"><em style="color: #333333;">It’s amazing what a simple Thanks can do! You’ve heard of being proactive. You can be the "pro" in active, by caring enough to give a Thanks of gratitude. Perfect for on-the-spot recognition of someone who did something kind for you.</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Thanks', '', 'inherit', 'closed', 'open', '', '53-revision-v1', '', '', '2014-08-14 20:13:32', '2014-08-14 20:13:32', '', 53, 'http://localhost/upwork/53-revision-v1/', 0, 'revision', '', 0),
(57, 2, '2014-08-16 15:17:58', '2014-08-16 15:17:58', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\r\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\r\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\r\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\r\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\r\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\r\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\r\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\r\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\r\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\r\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected.</p>\r\n<em><strong>It’s time to move UPwords!<br />Be the UP in someone’s life today!</strong></em>', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \r\nThe mini treasure found inside our cards can be likened to a fortune cookie, \r\ncapturing a powerful truth that goes straight to the heart. \r\n', 'publish', 'closed', 'open', '', 'about-upwords', '', '', '2014-08-16 15:34:37', '2014-08-16 15:34:37', '', 0, 'http://localhost/upwork/?p=57', 0, 'post', '', 0),
(58, 2, '2014-08-16 15:15:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-16 15:15:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=58', 0, 'post', '', 0),
(59, 2, '2014-08-16 15:15:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-16 15:15:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=59', 0, 'post', '', 0),
(60, 2, '2014-08-16 15:17:58', '2014-08-16 15:17:58', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\r\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\r\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\r\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\r\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\r\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\r\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\r\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\r\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\r\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\r\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected. It’s time to move UPwords!</p>\r\nBe the UP in someone’s life today!', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \r\nThe mini treasure found inside our cards can be likened to a fortune cookie, \r\ncapturing a powerful truth that goes straight to the heart. \r\n', 'inherit', 'closed', 'open', '', '57-revision-v1', '', '', '2014-08-16 15:17:58', '2014-08-16 15:17:58', '', 57, 'http://localhost/upwork/57-revision-v1/', 0, 'revision', '', 0),
(61, 2, '2014-08-16 15:18:58', '2014-08-16 15:18:58', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected.</p>\n<strong>It’s time to move UPwords!</strong>\nBe the UP in someone’s life today!', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \nThe mini treasure found inside our cards can be likened to a fortune cookie, \ncapturing a powerful truth that goes straight to the heart. \n', 'inherit', 'closed', 'open', '', '57-autosave-v1', '', '', '2014-08-16 15:18:58', '2014-08-16 15:18:58', '', 57, 'http://localhost/upwork/57-autosave-v1/', 0, 'revision', '', 0),
(62, 2, '2014-08-16 15:19:26', '2014-08-16 15:19:26', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\r\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\r\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\r\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\r\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\r\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\r\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\r\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\r\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\r\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\r\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected.</p>\r\n<em><strong>It’s time to move UPwords!</strong></em>\r\n<em><strong>Be the UP in someone’s life today!</strong></em>', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \r\nThe mini treasure found inside our cards can be likened to a fortune cookie, \r\ncapturing a powerful truth that goes straight to the heart. \r\n', 'inherit', 'closed', 'open', '', '57-revision-v1', '', '', '2014-08-16 15:19:26', '2014-08-16 15:19:26', '', 57, 'http://localhost/upwork/57-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `jc_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(63, 2, '2014-08-16 15:34:04', '2014-08-16 15:34:04', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\r\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\r\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\r\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\r\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\r\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\r\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\r\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\r\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\r\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\r\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected.</p>\r\n<em><strong>It’s time to move UPwords!\r\nBe the UP in someone’s life today!</strong></em>', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \r\nThe mini treasure found inside our cards can be likened to a fortune cookie, \r\ncapturing a powerful truth that goes straight to the heart. \r\n', 'inherit', 'closed', 'open', '', '57-revision-v1', '', '', '2014-08-16 15:34:04', '2014-08-16 15:34:04', '', 57, 'http://localhost/upwork/57-revision-v1/', 0, 'revision', '', 0),
(64, 2, '2014-08-16 15:34:37', '2014-08-16 15:34:37', '<p style="text-align: left;">What sparked the idea? Twenty years ago, a friend was facing a major life crisis and I wanted to encourage him. What started as little sticky notes on his kitchen cabinet, led to the distribution of hundreds of little handmade cards.. A simple idea caught on quickly and began selling in stores locally. It grew from there - a simple idea that caught on big.</p>\r\n<p style="text-align: left;">But then came technology, and our electronic hand held devices have stolen from us the impact of face to face connections. Sure it’s easy to shoot off a quick email, or a text a friend. But when our friends really need an encouraging word, or we really want to say, “THANKS”, or “CONGRATULATIONS”, face to face is so much more personal, and definitely more appreciated when said with UPwords little cards.</p>\r\n<p style="text-align: left;">Realizing that words carry power, we want to say something worth saying. At UPwords, we understand people want a hopeful card that expresses words that may be hard to find on our own. We don’t use additives and fillers to fluff up our cards.</p>\r\n<p style="text-align: left;">Imagine, you’ve just closed on your new house, and you are handed a little card with “CELEBRATE” written on it with a note of congratulations hand written inside from your friend who saw you through the whole process.</p>\r\n<p style="text-align: left;">Or, you are hurting from a recent loss or just going through a rough time, and you are handed a little card with “COMPASSION” written on it, with a hand written note of comfort and support on the inside.</p>\r\n<p style="text-align: left;">Perhaps your teen is facing a tough week of finals and you want him/her to know you are cheering him/her on. You can place the little card with “STRENGTH” written on it, and tuck it inside his textbook so it is discovered at that crucial testing time.</p>\r\n<p style="text-align: left;">How perfect it is for you to include one of these great little cards, along with a gift for your friend hosting a dinner party. So much more personal, and always more appreciated.</p>\r\n<p style="text-align: left;">Giving flowers to a friend and don’t want a big card to go with it? Let UPwords small card say a big word. If you want more than just the card available at your florist, see our “LOVE” card, or “JOY”, or “THANKS” card, etc.</p>\r\n<p style="text-align: left;">It’s time we all got back in touch - really in touch with those who mean the most to us. And UPwords cards are just way we can do that. UPwords cards literally stand alone!</p>\r\n<p style="text-align: left;">UPwords is unique because each card carries an element of surprise. The mini treasure found inside our cards can be likened to a fortune cookie, capturing a powerful truth that goes straight to the heart.</p>\r\n<p style="text-align: left;">The appeal of our little cards, which I wasn’t able to find elsewhere, is that we reach a very diverse demographic that connects us beyond age, gender, and culture. Our little cards are specifically designed to take out the middleman, the postman, and let YOU deliver. It’s how we turn a stranger into an acquaintance, and an acquaintance into a friend. It’s how we make these vital connections that all the technology in the world simply can’t replace. So it’s time to get connected.</p>\r\n<em><strong>It’s time to move UPwords!<br />Be the UP in someone’s life today!</strong></em>', 'ABOUT UPWords', 'UPwords is unique because each card carries an element of surprise.  \r\nThe mini treasure found inside our cards can be likened to a fortune cookie, \r\ncapturing a powerful truth that goes straight to the heart. \r\n', 'inherit', 'closed', 'open', '', '57-revision-v1', '', '', '2014-08-16 15:34:37', '2014-08-16 15:34:37', '', 57, 'http://localhost/upwork/57-revision-v1/', 0, 'revision', '', 0),
(65, 2, '2014-08-17 10:54:35', '2014-08-17 10:54:35', 'My friend just moved back to England &amp; I wanted to send a little something special in her mailbox - I already miss her!\r\nWhen Veronica received my card &amp; pix, she posted said, "I was having a ''pity party'' until I received this! Your card and pic brightened up my day!!!" XO<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/Veronica_2_large.jpg" alt="" /><br />\r\nA little UPwords card can surely go a long way - in distance &amp; in the heart! UPwords cards can be used as far as your imagination will take you!', 'Going the distance', '"Be the UP in someone''s life today!"', 'publish', 'closed', 'open', '', 'going-the-distance', '', '', '2014-08-17 11:09:38', '2014-08-17 11:09:38', '', 0, 'http://localhost/upwork/?p=65', 0, 'post', '', 0),
(66, 2, '2014-08-17 10:51:29', '2014-08-17 10:51:29', '', 'Veronica_2_large', '', 'inherit', 'closed', 'open', '', 'veronica_2_large', '', '', '2014-08-17 10:51:29', '2014-08-17 10:51:29', '', 65, 'http://localhost/upwork/wp-content/uploads/2014/08/Veronica_2_large.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 2, '2014-08-17 10:54:35', '2014-08-17 10:54:35', 'My friend just moved back to England &amp; I wanted to send a little something special in her mailbox - I already miss her!\r\nWhen Veronica received my card &amp; pix, she posted said, "I was having a ''pity party'' until I received this! Your card and pic brightened up my day!!!" XO\r\n\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Veronica_2_large.jpg" alt="" />\r\nA little UPwords card can surely go a long way - in distance &amp; in the heart! UPwords cards can be used as far as your imagination will take you!', 'Going the distance', '"Be the UP in someone''s life today!"', 'inherit', 'closed', 'open', '', '65-revision-v1', '', '', '2014-08-17 10:54:35', '2014-08-17 10:54:35', '', 65, 'http://localhost/upwork/65-revision-v1/', 0, 'revision', '', 0),
(68, 2, '2014-08-17 11:09:30', '2014-08-17 11:09:30', 'My friend just moved back to England &amp; I wanted to send a little something special in her mailbox - I already miss her!\nWhen Veronica received my card &amp; pix, she posted said, "I was having a ''pity party'' until I received this! Your card and pic brightened up my day!!!" XO<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/Veronica_2_large.jpg" alt="" /><br />\nA little UPwords card can surely go a long way - in distance &amp; in the heart! UPwords cards can be used as far as your imagination will take you!', 'Going the distance', '"Be the UP in someone''s life today!"', 'inherit', 'closed', 'open', '', '65-autosave-v1', '', '', '2014-08-17 11:09:30', '2014-08-17 11:09:30', '', 65, 'http://localhost/upwork/65-autosave-v1/', 0, 'revision', '', 0),
(69, 2, '2014-08-17 11:09:38', '2014-08-17 11:09:38', 'My friend just moved back to England &amp; I wanted to send a little something special in her mailbox - I already miss her!\r\nWhen Veronica received my card &amp; pix, she posted said, "I was having a ''pity party'' until I received this! Your card and pic brightened up my day!!!" XO<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/Veronica_2_large.jpg" alt="" /><br />\r\nA little UPwords card can surely go a long way - in distance &amp; in the heart! UPwords cards can be used as far as your imagination will take you!', 'Going the distance', '"Be the UP in someone''s life today!"', 'inherit', 'closed', 'open', '', '65-revision-v1', '', '', '2014-08-17 11:09:38', '2014-08-17 11:09:38', '', 65, 'http://localhost/upwork/65-revision-v1/', 0, 'revision', '', 0),
(70, 2, '2014-08-17 11:15:27', '2014-08-17 11:15:27', 'Can you recall a specific moment that you decided to step out of your comfort zone to do something nice for someone else? It probably felt quite uncomfortable, but you did it just the same! I like how Joyce Meyer''s says it, "Do it afraid!" Basically, do it anyways. Why? Because it is not until you give, that you receive.\r\nMy moment happened today when I decided to give my first UPwords card.\r\nThe new assortment of cards were delivered at 11:00am to my workplace. How thrilling to actually see and touch the big word in a small card greeting card. Wahoo! The very 1st card was given at 11:11am to a co-worker, who told me earlier about the loss of his 47 year old cousin.\r\nThe compassion card seemed to be a perfect choice of cards. Of the 8 life-themed cards, I left it on his desk as he was in a meeting. He later responded with an email that said, "With the precision ping of a percussion triangle, you touched my heart yesterday….."<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/20140402_110908_resized_medium.jpg" alt="" />', 'Step out', 'Choose to be the UP in someone''s life today!', 'publish', 'closed', 'open', '', 'step-out', '', '', '2014-08-17 11:17:17', '2014-08-17 11:17:17', '', 0, 'http://localhost/upwork/?p=70', 0, 'post', '', 0),
(71, 2, '2014-08-17 11:14:42', '2014-08-17 11:14:42', '', '20140402_110908_resized_medium', '', 'inherit', 'closed', 'open', '', '20140402_110908_resized_medium', '', '', '2014-08-17 11:14:42', '2014-08-17 11:14:42', '', 70, 'http://localhost/upwork/wp-content/uploads/2014/08/20140402_110908_resized_medium.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 2, '2014-08-17 11:15:27', '2014-08-17 11:15:27', 'Can you recall a specific moment that you decided to step out of your comfort zone to do something nice for someone else? It probably felt quite uncomfortable, but you did it just the same! I like how Joyce Meyer''s says it, "Do it afraid!" Basically, do it anyways. Why? Because it is not until you give, that you receive.\r\nMy moment happened today when I decided to give my first UPwords card.\r\nThe new assortment of cards were delivered at 11:00am to my workplace. How thrilling to actually see and touch the big word in a small card greeting card. Wahoo! The very 1st card was given at 11:11am to a co-worker, who told me earlier about the loss of his 47 year old cousin.\r\nThe compassion card seemed to be a perfect choice of cards. Of the 8 life-themed cards, I left it on his desk as he was in a meeting. He later responded with an email that said, "With the precision ping of a percussion triangle, you touched my heart yesterday….."<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/20140402_110908_resized_medium.jpg" alt="" />', 'Step out', '', 'inherit', 'closed', 'open', '', '70-revision-v1', '', '', '2014-08-17 11:15:27', '2014-08-17 11:15:27', '', 70, 'http://localhost/upwork/70-revision-v1/', 0, 'revision', '', 0),
(73, 2, '2014-08-17 11:17:17', '2014-08-17 11:17:17', 'Can you recall a specific moment that you decided to step out of your comfort zone to do something nice for someone else? It probably felt quite uncomfortable, but you did it just the same! I like how Joyce Meyer''s says it, "Do it afraid!" Basically, do it anyways. Why? Because it is not until you give, that you receive.\r\nMy moment happened today when I decided to give my first UPwords card.\r\nThe new assortment of cards were delivered at 11:00am to my workplace. How thrilling to actually see and touch the big word in a small card greeting card. Wahoo! The very 1st card was given at 11:11am to a co-worker, who told me earlier about the loss of his 47 year old cousin.\r\nThe compassion card seemed to be a perfect choice of cards. Of the 8 life-themed cards, I left it on his desk as he was in a meeting. He later responded with an email that said, "With the precision ping of a percussion triangle, you touched my heart yesterday….."<br /><img src="http://localhost/upwork/wp-content/uploads/2014/08/20140402_110908_resized_medium.jpg" alt="" />', 'Step out', 'Choose to be the UP in someone''s life today!', 'inherit', 'closed', 'open', '', '70-revision-v1', '', '', '2014-08-17 11:17:17', '2014-08-17 11:17:17', '', 70, 'http://localhost/upwork/70-revision-v1/', 0, 'revision', '', 0),
(74, 2, '2014-08-17 14:32:58', '2014-08-17 14:32:58', 'Here could be a short two sentence introduction that explains what this page is all about.\r\n"UpWords came about with the simple idea of touching lives face to face"', 'Life Stories', '', 'publish', 'closed', 'open', '', 'life-stories', '', '', '2014-08-17 14:33:22', '2014-08-17 14:33:22', '', 0, 'http://localhost/upwork/?p=74', 0, 'post', '', 0),
(75, 2, '2014-08-17 14:32:58', '2014-08-17 14:32:58', 'Here could be a short two sentence introduction that explains what this page is all about.\r\n"UpWords came about with the simple idea of touching lives face to face"', 'Life Stories', '', 'inherit', 'closed', 'open', '', '74-revision-v1', '', '', '2014-08-17 14:32:58', '2014-08-17 14:32:58', '', 74, 'http://localhost/upwork/74-revision-v1/', 0, 'revision', '', 0),
(76, 2, '2014-08-17 14:45:36', '2014-08-17 14:45:36', '<div class="img-content"><img class="aligncenter" src="http://localhost/upwork/wp-content/uploads/2014/08/Mom_Girl_Thank.jpg" alt="" /></div>\r\n<div class="text-content"><em style="color: #333333;">It’s amazing what a simple Thanks can do! You’ve heard of being proactive. You can be the "pro" in active, by caring enough to give a Thanks of gratitude. Perfect for on-the-spot recognition of someone who did something kind for you.</em>\r\n<ul style="color: #333333;">\r\n	<li>3.5 x 2 folded.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6331">Made of high quality 130lb. luxury paper with smooth, satiny finish &amp; exceptional writing surface.</li>\r\n	<li id="yui_3_13_0_1_1397524186692_6332">Ample space to write a personal note.</li>\r\n	<li>Sized for hand delivery.</li>\r\n	<li><span id="yui_3_13_0_1_1397524186692_6326"></span>Envelopes included.</li>\r\n</ul>\r\n</div>', 'Thanks', 'Our greeting card selection is a celebration of life in the fun written form and goes on a bit more to say... ', 'inherit', 'closed', 'open', '', '53-revision-v1', '', '', '2014-08-17 14:45:36', '2014-08-17 14:45:36', '', 53, 'http://localhost/upwork/53-revision-v1/', 0, 'revision', '', 0),
(77, 2, '2014-08-17 15:34:40', '2014-08-17 15:34:40', 'Words to live by day by day.', 'Kat, Florida', '', 'publish', 'closed', 'open', '', 'kat-florida', '', '', '2014-08-17 15:34:48', '2014-08-17 15:34:48', '', 0, 'http://localhost/upwork/?p=77', 0, 'post', '', 0),
(78, 2, '2014-08-17 15:34:35', '2014-08-17 15:34:35', '', 'ANGEL_Wife', '', 'inherit', 'closed', 'open', '', 'angel_wife', '', '', '2014-08-17 15:34:35', '2014-08-17 15:34:35', '', 77, 'http://localhost/upwork/wp-content/uploads/2014/08/ANGEL_Wife.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 2, '2014-08-17 15:34:40', '2014-08-17 15:34:40', 'Words to live by day by day.', 'Kat, Florida', '', 'inherit', 'closed', 'open', '', '77-revision-v1', '', '', '2014-08-17 15:34:40', '2014-08-17 15:34:40', '', 77, 'http://localhost/upwork/77-revision-v1/', 0, 'revision', '', 0),
(80, 2, '2014-08-17 15:36:25', '2014-08-17 15:36:25', 'These cards are like bubble wrap in the sense that I just can''t get enough! They make me feel inspired, connected.', 'Carey, Kansas', '', 'publish', 'closed', 'open', '', 'carey-kansas', '', '', '2014-08-17 15:36:25', '2014-08-17 15:36:25', '', 0, 'http://localhost/upwork/?p=80', 0, 'post', '', 0),
(81, 2, '2014-08-17 15:36:20', '2014-08-17 15:36:20', '', 'Carey', '', 'inherit', 'closed', 'open', '', 'carey', '', '', '2014-08-17 15:36:20', '2014-08-17 15:36:20', '', 80, 'http://localhost/upwork/wp-content/uploads/2014/08/Carey.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 2, '2014-08-17 15:36:25', '2014-08-17 15:36:25', 'These cards are like bubble wrap in the sense that I just can''t get enough! They make me feel inspired, connected.', 'Carey, Kansas', '', 'inherit', 'closed', 'open', '', '80-revision-v1', '', '', '2014-08-17 15:36:25', '2014-08-17 15:36:25', '', 80, 'http://localhost/upwork/80-revision-v1/', 0, 'revision', '', 0),
(83, 2, '2014-08-17 15:37:53', '2014-08-17 15:37:53', 'UPwords is a daily addition I don''t want to live without because it''s genuine & uplifting every day.', 'Michael, Massachusetts', '', 'publish', 'closed', 'open', '', 'michael-massachusetts', '', '', '2014-08-17 15:37:53', '2014-08-17 15:37:53', '', 0, 'http://localhost/upwork/?p=83', 0, 'post', '', 0),
(84, 2, '2014-08-17 15:37:49', '2014-08-17 15:37:49', '', 'Michael', '', 'inherit', 'closed', 'open', '', 'michael', '', '', '2014-08-17 15:37:49', '2014-08-17 15:37:49', '', 83, 'http://localhost/upwork/wp-content/uploads/2014/08/Michael.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 2, '2014-08-17 15:37:53', '2014-08-17 15:37:53', 'UPwords is a daily addition I don''t want to live without because it''s genuine & uplifting every day.', 'Michael, Massachusetts', '', 'inherit', 'closed', 'open', '', '83-revision-v1', '', '', '2014-08-17 15:37:53', '2014-08-17 15:37:53', '', 83, 'http://localhost/upwork/83-revision-v1/', 0, 'revision', '', 0),
(86, 2, '2014-08-17 15:39:01', '2014-08-17 15:39:01', 'Real encouragement for real life...that is what UPwords cards do best! Reminding your friend, co-worker, or family member that they are truly special is such a rarity. UPwords makes it easy and fun. For a small card, they sure do pack a big punch!', 'Keller, Georgia', '', 'publish', 'closed', 'open', '', 'keller-georgia', '', '', '2014-08-17 15:39:01', '2014-08-17 15:39:01', '', 0, 'http://localhost/upwork/?p=86', 0, 'post', '', 0),
(87, 2, '2014-08-17 15:38:55', '2014-08-17 15:38:55', '', 'Life_Stories4', '', 'inherit', 'closed', 'open', '', 'life_stories4', '', '', '2014-08-17 15:38:55', '2014-08-17 15:38:55', '', 86, 'http://localhost/upwork/wp-content/uploads/2014/08/Life_Stories4.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 2, '2014-08-17 15:39:01', '2014-08-17 15:39:01', 'Real encouragement for real life...that is what UPwords cards do best! Reminding your friend, co-worker, or family member that they are truly special is such a rarity. UPwords makes it easy and fun. For a small card, they sure do pack a big punch!', 'Keller, Georgia', '', 'inherit', 'closed', 'open', '', '86-revision-v1', '', '', '2014-08-17 15:39:01', '2014-08-17 15:39:01', '', 86, 'http://localhost/upwork/86-revision-v1/', 0, 'revision', '', 0),
(89, 2, '2014-08-17 15:41:34', '2014-08-17 15:41:34', 'AN REAL INSPIRATIONAL LIFE STORY QUOTE COULD BE PLACED HER  IN THE MIDDLE AS FEATURE TEXT THAT CAN BE CHANGED', 'Teresa - Roswell, GA', '', 'publish', 'closed', 'open', '', 'teresa-roswell-ga', '', '', '2014-08-17 15:53:17', '2014-08-17 15:53:17', '', 0, 'http://localhost/upwork/?p=89', 0, 'post', '', 0),
(90, 2, '2014-08-17 15:41:34', '2014-08-17 15:41:34', 'AN REAL INSPIRATIONAL \r\nLIFE STORY QUOTE COULD\r\nBE PLACED HER  IN THE\r\nMIDDLE AS FEATURE TEXT\r\nTHAT CAN BE CHANGED', 'Teresa - Roswell, GA', '', 'inherit', 'closed', 'open', '', '89-revision-v1', '', '', '2014-08-17 15:41:34', '2014-08-17 15:41:34', '', 89, 'http://localhost/upwork/89-revision-v1/', 0, 'revision', '', 0),
(91, 2, '2014-08-17 15:42:41', '2014-08-17 15:42:41', 'A few words can make a day so much brighter. I totally recommend these ''vitamines for life'' - take a daily dose and share with others! I think they''re brilliant!', 'Margriet, Netherlands', '', 'publish', 'closed', 'open', '', 'margriet-netherlands', '', '', '2014-08-17 15:42:41', '2014-08-17 15:42:41', '', 0, 'http://localhost/upwork/?p=91', 0, 'post', '', 0),
(92, 2, '2014-08-17 15:42:37', '2014-08-17 15:42:37', '', 'Life_Stories5', '', 'inherit', 'closed', 'open', '', 'life_stories5', '', '', '2014-08-17 15:42:37', '2014-08-17 15:42:37', '', 91, 'http://localhost/upwork/wp-content/uploads/2014/08/Life_Stories5.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 2, '2014-08-17 15:42:41', '2014-08-17 15:42:41', 'A few words can make a day so much brighter. I totally recommend these ''vitamines for life'' - take a daily dose and share with others! I think they''re brilliant!', 'Margriet, Netherlands', '', 'inherit', 'closed', 'open', '', '91-revision-v1', '', '', '2014-08-17 15:42:41', '2014-08-17 15:42:41', '', 91, 'http://localhost/upwork/91-revision-v1/', 0, 'revision', '', 0),
(94, 2, '2014-08-17 15:44:02', '2014-08-17 15:44:02', 'The cards are encouraging, a breath of fresh air, especially when life gets crazy. Thanks for taking the time to make an idea you had become a reality to change people''s lives with a simple message!', 'Sharon,Tezas', '', 'publish', 'closed', 'open', '', 'sharontezas', '', '', '2014-08-17 15:44:02', '2014-08-17 15:44:02', '', 0, 'http://localhost/upwork/?p=94', 0, 'post', '', 0),
(95, 2, '2014-08-17 15:43:58', '2014-08-17 15:43:58', '', 'Life_Stories6', '', 'inherit', 'closed', 'open', '', 'life_stories6', '', '', '2014-08-17 15:43:58', '2014-08-17 15:43:58', '', 94, 'http://localhost/upwork/wp-content/uploads/2014/08/Life_Stories6.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 2, '2014-08-17 15:44:02', '2014-08-17 15:44:02', 'The cards are encouraging, a breath of fresh air, especially when life gets crazy. Thanks for taking the time to make an idea you had become a reality to change people''s lives with a simple message!', 'Sharon,Tezas', '', 'inherit', 'closed', 'open', '', '94-revision-v1', '', '', '2014-08-17 15:44:02', '2014-08-17 15:44:02', '', 94, 'http://localhost/upwork/94-revision-v1/', 0, 'revision', '', 0),
(97, 2, '2014-08-17 15:45:08', '2014-08-17 15:45:08', 'I''m a big fan of UPwords! They make it easy to share a good word with others.', 'Susan, Colorado', '', 'publish', 'closed', 'open', '', 'susan-colorado', '', '', '2014-08-17 15:45:08', '2014-08-17 15:45:08', '', 0, 'http://localhost/upwork/?p=97', 0, 'post', '', 0),
(98, 2, '2014-08-17 15:45:01', '2014-08-17 15:45:01', '', 'Life_Stories7', '', 'inherit', 'closed', 'open', '', 'life_stories7', '', '', '2014-08-17 15:45:01', '2014-08-17 15:45:01', '', 97, 'http://localhost/upwork/wp-content/uploads/2014/08/Life_Stories7.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 2, '2014-08-17 15:45:08', '2014-08-17 15:45:08', 'I''m a big fan of UPwords! They make it easy to share a good word with others.', 'Susan, Colorado', '', 'inherit', 'closed', 'open', '', '97-revision-v1', '', '', '2014-08-17 15:45:08', '2014-08-17 15:45:08', '', 97, 'http://localhost/upwork/97-revision-v1/', 0, 'revision', '', 0),
(100, 2, '2014-08-17 15:45:47', '2014-08-17 15:45:47', 'With the big weight loss journey I have been going through, I am looking for inspirational things to pass on to others who are walking through their journeys in life. For myself, I would see an UPwords card and my day would change... especially when I would put it on my dashboard and look at it periodically throughout the day.', 'Betty, California', '', 'publish', 'closed', 'open', '', 'betty-california', '', '', '2014-08-17 15:45:47', '2014-08-17 15:45:47', '', 0, 'http://localhost/upwork/?p=100', 0, 'post', '', 0),
(101, 2, '2014-08-17 15:45:44', '2014-08-17 15:45:44', '', 'Life_Stories8', '', 'inherit', 'closed', 'open', '', 'life_stories8', '', '', '2014-08-17 15:45:44', '2014-08-17 15:45:44', '', 100, 'http://localhost/upwork/wp-content/uploads/2014/08/Life_Stories8.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 2, '2014-08-17 15:45:47', '2014-08-17 15:45:47', 'With the big weight loss journey I have been going through, I am looking for inspirational things to pass on to others who are walking through their journeys in life. For myself, I would see an UPwords card and my day would change... especially when I would put it on my dashboard and look at it periodically throughout the day.', 'Betty, California', '', 'inherit', 'closed', 'open', '', '100-revision-v1', '', '', '2014-08-17 15:45:47', '2014-08-17 15:45:47', '', 100, 'http://localhost/upwork/100-revision-v1/', 0, 'revision', '', 0),
(103, 2, '2014-08-17 15:53:17', '2014-08-17 15:53:17', 'AN REAL INSPIRATIONAL LIFE STORY QUOTE COULD BE PLACED HER  IN THE MIDDLE AS FEATURE TEXT THAT CAN BE CHANGED', 'Teresa - Roswell, GA', '', 'inherit', 'closed', 'open', '', '89-revision-v1', '', '', '2014-08-17 15:53:17', '2014-08-17 15:53:17', '', 89, 'http://localhost/upwork/89-revision-v1/', 0, 'revision', '', 0),
(104, 2, '2014-08-17 16:43:04', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-17 16:43:04', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=104', 0, 'post', '', 0),
(105, 2, '2014-08-17 16:43:22', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-17 16:43:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=105', 0, 'post', '', 0),
(106, 2, '2014-08-17 16:55:55', '2014-08-17 16:55:55', 'Here at UPwords, India continues to have an impact on our heart. Please join us in supporting at risk and abandoned children through their school &amp; orphanage.Click here to visit their website: <a href="http://www.jesusway.moonfruit.com">http://www.jesusway.moonfruit.com</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_Page_p1.png" alt="" />', 'Jesus Way International', '', 'publish', 'closed', 'open', '', 'jesus-way-international', '', '', '2014-08-17 16:55:55', '2014-08-17 16:55:55', '', 0, 'http://localhost/upwork/?p=106', 0, 'post', '', 0),
(107, 2, '2014-08-17 16:54:02', '2014-08-17 16:54:02', '', 'Web_Causes_PageP11', '', 'inherit', 'closed', 'open', '', 'web_causes_pagep11', '', '', '2014-08-17 16:54:02', '2014-08-17 16:54:02', '', 106, 'http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP11.png', 0, 'attachment', 'image/png', 0),
(108, 2, '2014-08-17 16:55:55', '2014-08-17 16:55:55', 'Here at UPwords, India continues to have an impact on our heart. Please join us in supporting at risk and abandoned children through their school &amp; orphanage.Click here to visit their website: <a href="http://www.jesusway.moonfruit.com">http://www.jesusway.moonfruit.com</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_Page_p1.png" alt="" />', 'Jesus Way International', '', 'inherit', 'closed', 'open', '', '106-revision-v1', '', '', '2014-08-17 16:55:55', '2014-08-17 16:55:55', '', 106, 'http://localhost/upwork/106-revision-v1/', 0, 'revision', '', 0),
(109, 2, '2014-08-17 16:58:44', '2014-08-17 16:58:44', 'UPwords is an on-going supporter of Kompas Park, a unique facility located in the heart of Ukraine. Click here to visit their website <a href="http://kompaspark.org" target="_blank">http://kompaspark.org</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP2.png" alt="" />', 'Kompas Park', '', 'publish', 'closed', 'open', '', 'kompas-park', '', '', '2014-08-17 16:58:44', '2014-08-17 16:58:44', '', 0, 'http://localhost/upwork/?p=109', 0, 'post', '', 0),
(110, 2, '2014-08-17 16:58:40', '2014-08-17 16:58:40', '', 'Web_Causes_PageP21', '', 'inherit', 'closed', 'open', '', 'web_causes_pagep21', '', '', '2014-08-17 16:58:40', '2014-08-17 16:58:40', '', 109, 'http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP21.png', 0, 'attachment', 'image/png', 0),
(111, 2, '2014-08-17 16:58:44', '2014-08-17 16:58:44', 'UPwords is an on-going supporter of Kompas Park, a unique facility located in the heart of Ukraine. Click here to visit their website <a href="http://kompaspark.org" target="_blank">http://kompaspark.org</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP2.png" alt="" />', 'Kompas Park', '', 'inherit', 'closed', 'open', '', '109-revision-v1', '', '', '2014-08-17 16:58:44', '2014-08-17 16:58:44', '', 109, 'http://localhost/upwork/109-revision-v1/', 0, 'revision', '', 0),
(112, 2, '2014-08-17 17:00:42', '2014-08-17 17:00:42', 'We support Genny’s Hope Foundation because of a very real connection to Genny, through knowing her Mom. Their mission is to increase the number of committed enrollments on the bone marrow donor registry by generating awareness and the desire of donors to test and register. Because of donor, Genny has her life ahead of her to help others.Click here to visit their website: <a href="http://www.volunteermatch.org/search/org536427.jsp" target="_blank">http://www.volunteermatch.org/search/org536427.jsp</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP3.png" alt="" />', 'Genny’s Hope Foundation', '', 'publish', 'closed', 'open', '', 'gennys-hope-foundation', '', '', '2014-08-17 17:00:42', '2014-08-17 17:00:42', '', 0, 'http://localhost/upwork/?p=112', 0, 'post', '', 0),
(113, 2, '2014-08-17 17:00:38', '2014-08-17 17:00:38', '', 'Web_Causes_PageP31', '', 'inherit', 'closed', 'open', '', 'web_causes_pagep31', '', '', '2014-08-17 17:00:38', '2014-08-17 17:00:38', '', 112, 'http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP31.png', 0, 'attachment', 'image/png', 0),
(114, 2, '2014-08-17 17:00:42', '2014-08-17 17:00:42', 'We support Genny’s Hope Foundation because of a very real connection to Genny, through knowing her Mom. Their mission is to increase the number of committed enrollments on the bone marrow donor registry by generating awareness and the desire of donors to test and register. Because of donor, Genny has her life ahead of her to help others.Click here to visit their website: <a href="http://www.volunteermatch.org/search/org536427.jsp" target="_blank">http://www.volunteermatch.org/search/org536427.jsp</a>\r\n<img src="http://localhost/upwork/wp-content/uploads/2014/08/Web_Causes_PageP3.png" alt="" />', 'Genny’s Hope Foundation', '', 'inherit', 'closed', 'open', '', '112-revision-v1', '', '', '2014-08-17 17:00:42', '2014-08-17 17:00:42', '', 112, 'http://localhost/upwork/112-revision-v1/', 0, 'revision', '', 0),
(115, 2, '2014-08-17 17:42:29', '2014-08-17 17:42:29', 'The product page', 'Product', '', 'publish', 'closed', 'open', '', 'product', '', '', '2014-08-17 17:42:29', '2014-08-17 17:42:29', '', 0, 'http://localhost/upwork/?page_id=115', 0, 'page', '', 0),
(116, 2, '2014-08-17 17:42:29', '2014-08-17 17:42:29', 'The product page', 'Product', '', 'inherit', 'closed', 'open', '', '115-revision-v1', '', '', '2014-08-17 17:42:29', '2014-08-17 17:42:29', '', 115, 'http://localhost/upwork/115-revision-v1/', 0, 'revision', '', 0),
(117, 2, '2014-08-17 17:58:20', '2014-08-17 17:58:20', 'Home', 'Home', '', 'inherit', 'closed', 'open', '', '5-revision-v1', '', '', '2014-08-17 17:58:20', '2014-08-17 17:58:20', '', 5, 'http://localhost/upwork/5-revision-v1/', 0, 'revision', '', 0),
(118, 2, '2014-08-19 06:52:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-08-19 06:52:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/upwork/?p=118', 0, 'post', '', 0),
(119, 2, '2014-08-19 07:02:16', '2014-08-19 07:02:16', '<div class="form-left">\r\n<div class="row">\r\n<label>First Name <span>*</span></label>\r\n    [text* first-name] </div>\r\n<div class="row">\r\n<label>Last Name <span>*</span></label>\r\n    [text* last-name] </div>\r\n<div class="row">\r\n<label>Email<span>*</span></label>\r\n     [email* your-email]  </div>\r\n<div class="row">\r\n<label>Home Phone </label>\r\n    [text hphone-name] </div>\r\n	<div class="row">\r\n<label>Cell phone</label>\r\n    [text cellphone-name] </div>\r\n</div>\r\n<div class="form-right">\r\n<div class="row message">\r\n<label>Your Message</label>\r\n    [textarea your-message] </div>\r\n\r\n<div class="sm">[submit "Send"]</div>	\r\n</div>\nThis e-mail was sent from a contact form on UPWORDS\n[your-name] < [your-email]>\nFrom: [your-name] < [your-email]>\r\nHome phone: [hphone-name]\r\nCell phone: [cellphone-name]\r\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on UPWORDS (http://localhost/upwork)\ntrungnguyenthanh70@gmail.com\n\n\n\n\n\n[your-subject]\n[your-name] < [your-email]>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on UPWORDS (http://localhost/upwork)\n[your-email]\n\n\n\n\nYour message was sent successfully. Thanks.\nFailed to send your message. Please try later or contact the administrator by another method.\nValidation errors occurred. Please confirm the fields and submit it again.\nFailed to send your message. Please try later or contact the administrator by another method.\nPlease accept the terms to proceed.\nPlease fill the required field.\nYour entered code is incorrect.\nNumber format seems invalid.\nThis number is too small.\nThis number is too large.\nEmail address seems invalid.\nURL seems invalid.\nTelephone number seems invalid.\nYour answer is not correct.\nDate format seems invalid.\nThis date is too early.\nThis date is too late.\nFailed to upload file.\nThis file type is not allowed.\nThis file is too large.\nFailed to upload file. Error occurred.', 'Contact form', '', 'publish', 'closed', 'open', '', 'contact-form-1', '', '', '2014-08-19 07:17:23', '2014-08-19 07:17:23', '', 0, 'http://localhost/upwork/?post_type=wpcf7_contact_form&#038;p=119', 0, 'wpcf7_contact_form', '', 0),
(120, 2, '2014-08-19 07:03:03', '2014-08-19 07:03:03', 'contact\r\n\r\n[contact-form-7 id="119" title="Contact form 1"]', 'Contact', '', 'inherit', 'closed', 'open', '', '22-revision-v1', '', '', '2014-08-19 07:03:03', '2014-08-19 07:03:03', '', 22, 'http://localhost/upwork/22-revision-v1/', 0, 'revision', '', 0),
(121, 2, '2014-08-19 07:09:49', '2014-08-19 07:09:49', 'contact\r\n\r\n[contact-form-7 id="119" title="Contact form"]', 'Contact', '', 'inherit', 'closed', 'open', '', '22-revision-v1', '', '', '2014-08-19 07:09:49', '2014-08-19 07:09:49', '', 22, 'http://localhost/upwork/22-revision-v1/', 0, 'revision', '', 0),
(122, 2, '2014-08-19 07:12:53', '2014-08-19 07:12:53', 'UpWords,\n\nPO Box 958152\n\nDuluth , GA 30095\n\ninfo@upwords.me\n\n[contact-form-7 id="119" title="Contact form"]', 'Contact', '', 'inherit', 'closed', 'open', '', '22-autosave-v1', '', '', '2014-08-19 07:12:53', '2014-08-19 07:12:53', '', 22, 'http://localhost/upwork/22-autosave-v1/', 0, 'revision', '', 0),
(123, 2, '2014-08-19 07:13:07', '2014-08-19 07:13:07', '<strong>UpWords</strong>\r\n\r\nPO Box 958152\r\n\r\nDuluth , GA 30095\r\n\r\ninfo@upwords.me\r\n\r\n[contact-form-7 id="119" title="Contact form"]', 'Contact', '', 'inherit', 'closed', 'open', '', '22-revision-v1', '', '', '2014-08-19 07:13:07', '2014-08-19 07:13:07', '', 22, 'http://localhost/upwork/22-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jc_terms`
--

CREATE TABLE IF NOT EXISTS `jc_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jc_terms`
--

INSERT INTO `jc_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Home Page', 'home', 0),
(2, 'Primary Navigation', 'primary-navigation', 0),
(3, 'Shop', 'shop', 0),
(4, 'Life Stories', 'life', 0),
(5, 'About', 'about', 0),
(6, 'Causes', 'causes', 0),
(7, 'Blog', 'blog', 0),
(8, 'Contact', 'contact', 0),
(9, 'Product', 'product', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jc_term_relationships`
--

CREATE TABLE IF NOT EXISTS `jc_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jc_term_relationships`
--

INSERT INTO `jc_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(7, 2, 0),
(8, 2, 0),
(30, 1, 0),
(30, 3, 0),
(33, 1, 0),
(33, 3, 0),
(53, 1, 0),
(53, 3, 0),
(57, 5, 0),
(65, 7, 0),
(70, 7, 0),
(74, 4, 0),
(77, 4, 0),
(80, 4, 0),
(83, 4, 0),
(86, 4, 0),
(89, 4, 0),
(91, 4, 0),
(94, 4, 0),
(97, 4, 0),
(100, 4, 0),
(106, 6, 0),
(109, 6, 0),
(112, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jc_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `jc_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jc_term_taxonomy`
--

INSERT INTO `jc_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', 'Post on home page if existing.', 0, 4),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'category', 'Post on shop page', 0, 4),
(4, 4, 'category', 'Post on Life Stories page', 0, 10),
(5, 5, 'category', 'Post on page About', 0, 1),
(6, 6, 'category', 'Post on causes page', 0, 3),
(7, 7, 'category', 'Post on Blog page', 0, 2),
(8, 8, 'category', 'Post on contact page if existing.', 0, 0),
(9, 9, 'category', 'The product category', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jc_usermeta`
--

CREATE TABLE IF NOT EXISTS `jc_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `jc_usermeta`
--

INSERT INTO `jc_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'jimmy'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'jc_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'jc_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'jc_dashboard_quick_press_last_post_id', '3'),
(15, 2, 'first_name', ''),
(16, 2, 'last_name', ''),
(17, 2, 'nickname', 'admin'),
(18, 2, 'description', ''),
(19, 2, 'rich_editing', 'true'),
(20, 2, 'comment_shortcuts', 'false'),
(21, 2, 'admin_color', 'fresh'),
(22, 2, 'use_ssl', '0'),
(23, 2, 'show_admin_bar_front', 'true'),
(24, 2, 'jc_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(25, 2, 'jc_user_level', '0'),
(26, 2, 'default_password_nag', ''),
(27, 2, 'dismissed_wp_pointers', 'wp390_widgets,wp350_media,wp360_revisions'),
(28, 2, 'nav_menu_recently_edited', '2'),
(29, 2, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(30, 2, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(31, 2, 'jc_dashboard_quick_press_last_post_id', '118'),
(32, 2, 'closedpostboxes_post', 'a:0:{}'),
(33, 2, 'metaboxhidden_post', 'a:4:{i:0;s:13:"trackbacksdiv";i:1;s:16:"commentstatusdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}'),
(34, 2, 'jc_user-settings', 'editor=tinymce&libraryContent=browse&hidetb=1&dfw_width=626'),
(35, 2, 'jc_user-settings-time', '1408294550'),
(36, 2, 'meta-box-order_post', 'a:3:{s:4:"side";s:61:"submitdiv,formatdiv,categorydiv,tagsdiv-post_tag,postimagediv";s:6:"normal";s:83:"postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(37, 2, 'screen_layout_post', '2');

-- --------------------------------------------------------

--
-- Table structure for table `jc_users`
--

CREATE TABLE IF NOT EXISTS `jc_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jc_users`
--

INSERT INTO `jc_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'jimmy', '$P$BFSl5lQjMLY6nSkOkNlgoquxnDKbRY1', 'jimmy', 'trungnguyenthanh70@gmail.com', '', '2014-08-09 13:43:51', '', 0, 'jimmy'),
(2, 'admin', '$P$BgSK/n8AcrVh3rc4tsJwA/Bnij4tdl/', 'admin', 'duytucntt@gmail.com', '', '2014-08-10 17:44:33', '', 0, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
